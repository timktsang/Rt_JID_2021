library(chron)
setwd("/Users/timtsang/SPH Dropbox/Tim Tsang/2019nCoV/rt_method/program_rcpp/simulation/v5/value1")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]

nsim <- 50

nday <- 70
smooth <- 14
startpt <- 5

int_para <- c(rep(0,10),rep(1,nday-startpt+1),rep(1.5,nday-startpt+1))

#### rt
tt1 <- tt2 <- tt3 <- matrix(NA,nsim,length(int_para))


for (i in 1:nsim){
  temp <- read.csv(rawlist1[i])  
  tt1[i,] <- temp[,1]
  tt2[i,] <- temp[,2]
  tt3[i,] <- temp[,3]
  #tt2[i,] <- 1*(temp[,2] <= int_para & temp[,3] >= int_para)
  
}

summary(tt1)
summary(tt2)

adjset <- 0.04


### simulation figure
pdf("figure_sim.pdf",width=7, height=6)
par(mar=c(4,3,1,0), mfrow=c(2,1))

plot(NA, xlim=c(1,nday), ylim=c(0,3), axes=F, ann=F)

axis(1, at=(0:(nday/10)*10), pos=0)
axis(2, at=0:3, las=1, pos=0)
plotlen <- 12:(nday-startpt+1)
plotlen2 <- plotlen + 10
for (i in 1:nsim){
  lines(plotlen+4, int_para[plotlen2],col=rgb(1,0,0,0.3))
  lines(plotlen+4, tt1[i,plotlen2],col=rgb(0,0,0,0.3))
  lines(plotlen+4, tt2[i,plotlen2],col=rgb(0,0,1,0.05))
  lines(plotlen+4, tt3[i,plotlen2],col=rgb(0,0,1,0.05))
}
#lines(1:upto,int_para[1:upto],col="red")
mtext("Days since epidemics",1,line=2)
mtext(expression(paste("R"[t]," for imported cases",sep="")),2,line=1.5)
title(main="A", adj=adjset )

plot(NA, xlim=c(1,nday), ylim=c(0,3), axes=F, ann=F)

axis(1, at=(0:(nday/10)*10), pos=0)
axis(2, at=0:3, las=1, pos=0)
plotlen <- 12:(nday-startpt+1)
plotlen2 <- plotlen + 10 + (nday-startpt+1)
for (i in 1:nsim){
  lines(plotlen+4, int_para[plotlen2],col=rgb(1,0,0,0.3))
  lines(plotlen+4, tt1[i,plotlen2],col=rgb(0,0,0,0.3))
  lines(plotlen+4, tt2[i,plotlen2],col=rgb(0,0,1,0.05))
  lines(plotlen+4, tt3[i,plotlen2],col=rgb(0,0,1,0.05))
}
#lines(1:upto,int_para[1:upto],col="red")
mtext("Days since epidemics",1,line=2)
mtext(expression(paste("R"[t]," for local cases",sep="")),2,line=1.5)
title(main="B", adj=adjset )

dev.off()


