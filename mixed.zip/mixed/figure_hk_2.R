library(chron)
## get the epidemic curve and growth rate
rm(list = ls())
set.seed(as.numeric(Sys.time()))


today <- as.Date("2020-08-06")

uu <- today - as.Date(dates("01/17/2020"))

data <- read.csv("/Users/timtsang/Dropbox/Shared HK 2019nCoV/data_CHP/enhanced_surveillance/hkcase_20200807.csv",as.is = T)
data$type[data$reclassification%in%c("Imported")] <- 1
data$type[data$reclassification%in%c("Epidemiologically linked with imported case")] <- 2
data$type[data$reclassification%in%c("Local case","Possibly local")] <- 3
data$type[data$reclassification%in%c("Epidemiologically linked with possibly local case","Epidemiologically linked with local case")] <- 4
data$type[is.na(data$type)] <- 2
#reclass <- read.csv("cluster_classification_21may.csv")
#data <- merge(data,reclass[,c("case.no","new.classification")],by="case.no",all.x=T)
#data$type <- NA
#data$type[data$new.classification%in%c("imported index case","sporadic imported case")] <- 1
#data$type[data$new.classification%in%c("linked to imported index")] <- 2
#data$type[data$new.classification%in%c("local index case","sporadic local case")] <- 3
#data$type[data$new.classification%in%c("linked to local index")] <- 4




data$onset.date <- dates(data$onset.date,format="d/m/y")
data$confirm.date <- dates(data$confirm.date,format="d/m/y") 
data$confirm.date[1603] <-  dates("16/07/2020",format="d/m/y") 
data$onset.date[is.na(data$onset.date)] <- data$confirm.date[is.na(data$onset.date)]
data <- data[data$confirm.date<=today,]
data_org <- data
data$onset.date[1686] <- data$onset.date[1687]+1
#data <- data[!data$reclassification%in%c("Imported"),]
data$onset.date <- as.Date(as.character(data$onset.date),"%m/%d/%y")

data$confirm.date <- as.Date(as.character(data$confirm.date),"%m/%d/%y")


yrlimit <- 3.5
onset.date.range <- c(min(data$onset.date, na.rm=T), max(data$onset.date, na.rm=T))

unique.onset.date <- sort(unique(data$onset.date))
n.date <- today-onset.date.range[1]

data.onset <- data.frame(matrix(NA,n.date+1,5))
names(data.onset) <- c("date.onset","case","cum.case","import","cum.import")
data.onset[,1] <- onset.date.range[1]+1:(n.date+1)-1 
for (i in 1:(n.date+1)){
data.onset$case[i] <- sum(data$onset.date==data.onset$date.onset[i]&!data$reclassification%in%c("Imported"),na.rm = T)  
data.onset$import[i] <- sum(data$onset.date==data.onset$date.onset[i]&data$reclassification%in%c("Imported"),na.rm = T)  
data.onset$type1[i] <- sum(data$onset.date==data.onset$date.onset[i]&data$type==1,na.rm = T) 
data.onset$type2[i] <- sum(data$onset.date==data.onset$date.onset[i]&data$type==2,na.rm = T) 
data.onset$type3[i] <- sum(data$onset.date==data.onset$date.onset[i]&data$type==3,na.rm = T) 
data.onset$type4[i] <- sum(data$onset.date==data.onset$date.onset[i]&data$type==4,na.rm = T) 
}


#data.onset$type4[130]

data.onset$cum.case <- cumsum(data.onset$case)
data.onset$cum.import <- cumsum(data.onset$import)

date.lab.day <- gsub("(?<![0-9])0+", "", format(onset.date.range[1]+0:300,'%d'), perl=T)
date.lab.day[1:length(date.lab.day)%%7!=2] <- NA

bar.hwid=0.45

pdf(paste("/Users/timtsang/Dropbox/2019nCoV/rt_daily/HK_Figure_",today,".pdf",sep = ""),width=10, height=7)
par(mar=c(4,3,1,0), mfrow=c(2,1))

adjset <- 0.04

#######################################################################################################
# read the backfilling result
max.y1=140
backfillsample <- NA #read.csv("/Users/timtsang/Dropbox/2019nCoV/rt_daily/v1_0720_v3/caseimpute.csv")[-c(1:17),-1]
for (i in 1:nrow(data.onset)){
  data.onset$backfilled[i] <-  backfillsample[i,1] 
  data.onset$backfilled.lower[i] <- backfillsample[i,2]
  data.onset$backfilled.upper[i] <- backfillsample[i,3]
}



bar.hwid=0.45

plot(NA, xlim=c(onset.date.range[1]-1, today), ylim=c(0,max.y1*1.05), axes=F, ann=F)
axis(1, at=(onset.date.range[1])+0:300-0.5, lab=NA, pos=0, padj=-0.5)
axis(1, at=(onset.date.range[1])+0:299, lab=date.lab.day[1:300], pos=0, padj=-0.5, tick=F,cex.axis=1)
axis(1, at=onset.date.range[1]+c(14,43,74,104,135,165)-0.5,labels = NA, pos=0, padj=1.3,tck=-0.2)
axis(1, at=onset.date.range[1]+c(7,28.5,59.5,89.5,119.5,149.5,179.5)-1 , lab=c("January","February","March","April","May","June","July"), pos=0, padj=1.2, tick=F)
lines(c(onset.date.range[1]-1,onset.date.range[1]), c(0,0))
axis(2, at=0:14*10, las=1, pos=onset.date.range[1]-1)
title(main="A", adj=adjset )
for (i in 1:(n.date+1)){
  polygon(c(rep(data.onset$date[i]-bar.hwid,2),rep(data.onset$date[i]+bar.hwid,2)), 
          c(0,rep(data.onset$type4[i],2), 0), col='orange', border=F)	 #dodgerblue2
  
   polygon(c(rep(data.onset$date[i]-bar.hwid,2),rep(data.onset$date[i]+bar.hwid,2)), 
          c(data.onset$type4[i],rep(data.onset$type4[i]+data.onset$type3[i],2), data.onset$type4[i]), col='red', border=F)	 #dodgerblue2
  
   
   polygon(c(rep(data.onset$date[i]-bar.hwid,2),rep(data.onset$date[i]+bar.hwid,2)), 
           c(data.onset$type4[i]+data.onset$type3[i],rep(data.onset$type4[i]+data.onset$type2[i]+data.onset$type3[i],2), data.onset$type4[i]+data.onset$type3[i]), col='lightblue2', border=F)	 #dodgerblue2
   
   polygon(c(rep(data.onset$date[i]-bar.hwid,2),rep(data.onset$date[i]+bar.hwid,2)), 
           c(data.onset$type4[i]+data.onset$type2[i]+data.onset$type3[i],rep(data.onset$type1[i]+data.onset$type2[i]+data.onset$type3[i]+data.onset$type4[i],2), data.onset$type4[i]+data.onset$type2[i]+data.onset$type3[i]), col='dodgerblue2', border=F)	 #dodgerblue2
   
   
  
 # if (i >=uu-25){
    if (i >=uu-10){
 #   polygon(c(rep(data.onset$date[i]-bar.hwid,2),rep(data.onset$date[i]+bar.hwid,2)), 
 #           c(data.onset$backfilled.lower[i],rep(data.onset$backfilled.upper[i],2), data.onset$backfilled.lower[i]), col=rgb(0,0,0,0.2), border=F)	 #dodgerblue2
    lines(data.onset$date[i]+c(-1,1)*0.5,rep(data.onset$backfilled [i],2),col="black")
    lines(rep(data.onset$date[i]-0.5,2),c(data.onset$backfilled [i],data.onset$backfilled [i-1]),col="black")

    lines(data.onset$date[i]+c(-1,1)*0.5,rep(data.onset$backfilled.upper [i],2),col="black",lty=3)
    lines(rep(data.onset$date[i]-0.5,2),c(data.onset$backfilled.upper [i],data.onset$backfilled.upper [i-1]),col="black",lty=3)
    
    lines(data.onset$date[i]+c(-1,1)*0.5,rep(data.onset$backfilled.lower [i],2),col="black",lty=3)
    lines(rep(data.onset$date[i]-0.5,2),c(data.onset$backfilled.lower [i],data.onset$backfilled.lower [i-1]),col="black",lty=3)
    
    
      }
}
legend(onset.date.range[1]+80,120,c("Imported cases","Unlinked local cases","Local cases linked with imported cases","Local cases linked with local cases")
       ,cex=1.1,bty="n",fill=c("dodgerblue2","red","lightblue2","orange"),border=NA,x.intersp=c(1.5))

#legend(onset.date.range[1],32,c("Augmented incidence of local cases: Mean")
#       ,cex=1.1,bty="n",lty=c(1),col=c("orange"),border=NA,x.intersp=c(1))

#legend(onset.date.range[1]+1,28,c("Augmented incidence of local cases: CI")
#       ,cex=1.1,bty="n",fill=c(rgb(1,0.63,0,0.2)),border=NA,x.intersp=c(1.5))


mtext('Date of symptom onset', 1, line=2.5)
mtext('No. cases', 2, line=1)

## here compute the shift
uu2 <- uu+17
startpt <- 24-16

rest <- read.csv(paste("/Users/timtsang/Dropbox/2019nCoV/test/program_rcpp_HK_raw/mcmc_summary_",uu2,"_1.csv",sep=""))
rest <- read.csv("/Users/timtsang/Dropbox/2019nCoV/rt_daily/v1_0807/combined_200.csv")
totaln <- (nrow(rest)-10)/2

data.onset[nrow(data.onset)-(totaln-1):0,c("rt1","rt1.1","rt1.2")] <- rest[10+1:totaln,1:3]
data.onset[nrow(data.onset)-(totaln-1):0,c("rt2","rt2.1","rt2.2")] <- rest[10+1:totaln+totaln,1:3]

data.onset[nrow(data.onset)-39:14,c("rt2","rt2.1","rt2.2")]  <- data.onset[nrow(data.onset)-39:14,c("rt2","rt2.1","rt2.2")]*(1-(14:39-14)*0.0075)

data.onset[nrow(data.onset)-13:7,c("rt2","rt2.1","rt2.2")]  <- data.onset[nrow(data.onset)-13:7,c("rt2","rt2.1","rt2.2")]*(c(1-(13:7-5)*0.02)-c(rep(0,3),rep(0.03,4)))
data.onset[nrow(data.onset)-16:7,c("rt2.1")] <- data.onset[nrow(data.onset)-16:7,c("rt2.1")]*0.97
data.onset[nrow(data.onset)-16:7,c("rt2.2")] <- data.onset[nrow(data.onset)-16:7,c("rt2.2")]*1.03

#data.onset[nrow(data.onset)-12:7,c("rt2","rt2.1","rt2.2")] 

yrlimit <- 4
data.onset2 <- data.onset[(uu-14):(uu-7),]
data.onset <- data.onset[1:(uu-7),]
plot(NA, xlim=c(onset.date.range[1]-1, today), ylim=c(0,yrlimit*1.05), axes=F, ann=F)
axis(1, at=(onset.date.range[1])+0:300-0.5, lab=NA, pos=0, padj=-0.5)
axis(1, at=(onset.date.range[1])+0:299, lab=date.lab.day[1:300], pos=0, padj=-0.5, tick=F,cex.axis=1)
axis(1, at=onset.date.range[1]+c(14,43,74,104,135,165)-0.5,labels = NA, pos=0, padj=1.3,tck=-0.2)
axis(1, at=onset.date.range[1]+c(7,28.5,59.5,89.5,119.5,149.5,179.5)-1 , lab=c("January","February","March","April","May","June","July"), pos=0, padj=1.2, tick=F)
lines(c(onset.date.range[1]-1,onset.date.range[1]), c(0,0))
axis(2, at=0:(yrlimit*2)*0.5, las=1, pos=onset.date.range[1]-1)

lines(c(onset.date.range[1]-1, today),c(1,1),lty=2)

xvec <- data.onset[,1]
lines(xvec,data.onset$rt1,lty=1)
polygon(c(xvec,rev(xvec)), c(data.onset$rt1.1,rev(data.onset$rt1.2) ), col=rgb(0,0,0,0.1), border=F)	

xvec2 <- data.onset2[,1]
#lines(xvec2,data.onset2$rt1,lty=1)
#polygon(c(xvec2,rev(xvec2)), c(data.onset2$rt1.1,rev(data.onset2$rt1.2) ), col=rgb(0,0,1,0.1), border=F)	

#lines(xvec,data.onset$rt11,lty=2)
#lines(xvec,data.onset$rt12,lty=3)


lines(xvec,data.onset$rt2,lty=1,col="red")
#lines(xvec,data.onset$rt21,lty=2,col="red")
#lines(xvec,data.onset$rt22,lty=3,col="red")
#lines(xvec2,data.onset2$rt2,lty=1,col="blue")


polygon(c(xvec,rev(xvec)), c(data.onset$rt2.1,rev(data.onset$rt2.2) ), col=rgb(1,0,0,0.1), border=F)	
#polygon(c(xvec2,rev(xvec2)), c(data.onset2$rt2.1,rev(data.onset2$rt2.2) ), col=rgb(0,0,1,0.1), border=F)	


mtext('Date', 1, line=2.5)
mtext('Effective reproductive number', 2, line=1)

legend(onset.date.range[1]+60,4.2,c("Rt of local cases","Rt of imported cases")
       ,cex=1.1,bty="n",lty=1,col=c("red","black"),border=NA,x.intersp=c(1.5))

#legend(onset.date.range[1]+40,4.2,c("same detection rate","20% more detection rate for imported cases","50% more detection rate for imported cases")
#       ,cex=1.1,bty="n",lty=1:3,border=NA,x.intersp=c(1.5))

title(main="B", adj=adjset )

dev.off()

#####
dataout <- data.onset[,c("date.onset","rt1","rt1.1","rt1.2","rt2","rt2.1","rt2.2")]
names(dataout) <- c("data.onset","imported.rt.mean","imported.rt.lower","imported.rt.upper","local.rt.mean","local.rt.lower","local.rt.upper")
#write.csv(dataout,"/Users/timtsang/Dropbox/2019nCoV/rt_daily/rt.csv")
dataout$date <- dates(dates(as.character(dataout$data.onset),format="y-m-d"),format="%d/%m/%y")
dataout$dateX <- strptime(dataout$date , "%m/%d/%y")
dataout$date <- format(dataout$dateX , "%d/%m/%Y")
dataout <- dataout[!is.na(dataout$imported.rt.mean),]

dataout1 <- dataout[,c("local.rt.mean","local.rt.lower","local.rt.upper","date")]
dataout2 <- dataout[,c("imported.rt.mean","imported.rt.lower","imported.rt.upper","date")]

write.csv(dataout1,paste("/Users/timtsang/Dropbox/2019nCoV/rt_daily/",today,"_rt.csv",sep=""),row.names = F)
write.csv(dataout2,paste("/Users/timtsang/Dropbox/2019nCoV/rt_daily/",today,"_rt_imported.csv",sep=""),row.names = F)
