
rm(list = ls())

library(surveillance)
library(Rcpp)
library(RcppParallel)
library(chron)
library(mvtnorm)

########
# set link
#setwd("/Users/timtsang/Dropbox/2019nCoV/rt_method/realdata3/main2")
#setwd("z:/2019nCoV/2020_09_paper2/v1")
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  y[i,1] <- mean(mcmc[,i])
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


#####################################################################
## here sample the incubation meanlog and sdlog

meanvec <- c(1.4341,0.6613)
sdmat <- matrix(c(0.08005,-0.01121,-0.01121,0.03558),nrow=2)

incpara <- rmvnorm(1,mean=meanvec,sigma=sdmat)
#incpara <- meanvec

incvec <- (plnorm(1:20,incpara[1],incpara[2])-plnorm(0:19,incpara[1],incpara[2]))/plnorm(20,incpara[1],incpara[2])


## infectiousness, shifted gamma distribution f_c(x) = f(x+c) with parameters 
infpara <- c(20.52,1.59,12.27)
infvec <- (pgamma(1:40,infpara[1],infpara[2])-pgamma(0:39,infpara[1],infpara[2]))


w_dis1 <- rep(0,20)
for (i in 1:20){
  for (j in 1:40){
    if (i+j-12>0&(i+j-12<=20)){  
      w_dis1[i+j-12] <- w_dis1[i+j-12] + incvec[i]*infvec[j]  
    }
  }  
}
w_dis2 <- w_dis1
w_dis2[1:5] <- 0
w_dis <- cbind(w_dis2/sum(w_dis2),w_dis1/sum(w_dis1))


##############################################################################
## change the date for the data set here ( today mean cutoff of the dataset, not the actual date)
data2raw <- read.csv("hkcase_20201028.csv",as.is=T)
data2rawcopy <- data2raw
data2raw$type <- NA
data2raw$type[data2raw$reclassification%in%c("Imported")] <- 1
data2raw$type[data2raw$reclassification%in%c("Epidemiologically linked with Imported")] <- 2
data2raw$type[data2raw$reclassification%in%c("Local case","Possibly local")] <- 3
data2raw$type[data2raw$reclassification%in%c("Epidemiologically linked with local case")] <- 4


today <- dates("05/08/2020")
refdate <- dates("12/31/2019")

##############################################################################
uu <- today - refdate 
startpt <- 24

# time series of  1. imported, 2. contact of imported, 3. unlinked local, 4. contact of local
data1 <- matrix(NA,uu,4)

## for assume those asympotmatic will has symptom next date and record it.
## pay attention on the date format
data2raw$onset.date <- dates(data2raw$onset.date,format="d/m/y") - refdate 
data2raw$confirm.date <- dates(data2raw$confirm.date,format="d/m/y") - refdate 
#data2raw$onset.date[data2rawcopy$onset.date=="Asymptomatic"] <- data2raw$confirm.date[data2rawcopy$onset.date=="Asymptomatic"] - 1
#data2raw$onset.date[is.na(data2raw$onset.date)] <- data2raw$confirm.date[is.na(data2raw$onset.date)] - floor(rgamma(sum(is.na(data2raw$onset.date)),1.47,1/3.23))+1
data2raw$interval <- data2raw$confirm.date - data2raw$onset.date
#data2raw <- data2raw[sample(1:nrow(data2raw),replace=T),]
data2raw$interval[is.na(data2raw$interval)] <- -1


for (i in 1:nrow(data1)){
  for (j in 1:4){
    data1[i,j] <- sum(data2raw$confirm.date==i&data2raw$type==j,na.rm=T)
  }
}

# the reporting for the 4 types
data2 <- matrix(-1,nrow(data2raw),4)
for (j in 1:4){
  data2[data2raw$type==j,j] <-  data2raw$interval[data2raw$type==j]
}

data1 <- as.matrix(data1)
data2 <- as.matrix(data2)

###############################################################
## for sampling reporting delay
## here get the empirical dist
delay <- matrix(NA,20,4)
  for (j in 1:4){
    delay[20,j] <- sum(data2[,j]>=20)  
    for (i in 1:19){
    delay[i,j] <- sum(data2[,j]==i)  
  }
}


for (j in 1:4){
  delay[,j] <- delay[,j]/sum(delay[,j])
}

## generate concvolution
rint <- matrix(0,40,4)

for (k in 1:4){
for (i in 1:20){
  for (j in 1:20){
    if (i+j>0&(i+j<=40)){  
      rint[i+j,k] <- rint[i+j,k] + incvec[i]*delay[j,k]  
    }
  }  
}
}

## cut the data for simulation
#data1 <- data1[1:70,]

## sim data here
sourceCpp("rt.cpp")
misprob <- c(0.5,0.5)
int_para <- c(rep(0,10),rep(1,nrow(data1)-startpt+1),rep(1.5,nrow(data1)-startpt+1))


tt <- sim_data(data1,int_para,w_dis,rint,misprob,startpt)

######### here do decon
#data1 <- tt[[3]]

decondata <- matrix(0,nrow(data1),4)

for (j in c(1,2,3,4)){
  temp <- sts(data1[,j])
  bpnp.control <- list(k=0,eps=rep(1,2),iter.max=rep(250,2),B=-1,verbose=TRUE)
  temp2 <- backprojNP(temp ,incu.pmf=c(0,rint[,j]),
                      control=modifyList(bpnp.control,list(eq3a.method="C")), ylim=c(0,max(X,Y)))
  print(sum(temp2@upperbound)-sum(data1[,j]))
  output <- (temp2@upperbound)/sum(temp2@upperbound)*sum(data1[,j])
  decondata[,j] <- output
}


data1 <- decondata
## add a sampling for unlinked local
for (i in 1:nrow(data1)){
if (data1[i,3]>0){
  samplev <- runif(1,0.01,0.99)
  data1[i,4] <- data1[i,4]+data1[i,3]*samplev
  data1[i,2] <- data1[i,2]+data1[i,3]*(1-samplev)
  data1[i,3] <- 0
}
}

#### here sample the decon by poi dist

data11 <- data1

for (i in 1:nrow(data1)){
  for (j in 1:ncol(data1)){
    data11[i,j] <- round(   rpois(1,data1[i,j] )  )  
  }  
}




smooth <- 14

# first 10 is to resevere for parameters other than Rt
para <- c(rep(0,10),rep(1,nrow(data1)-startpt+1))
move <- rep(1,length(para))
move[1:10] <- 0
para[1:10] <- 0
sigma <- (abs(para)+0.1)/5


aaaaa1 <- Sys.time()
tt <- mcmc(data11,para,w_dis,misprob,smooth,startpt,5000,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)



id <- runif(1,0,1)
inc <- 1000+1:4000
z1 <- para_summary((tt[[1]][inc,]),4,3,1)
plot(tt[[2]][inc,1])
print(z1)


#save.image(paste("test_",uu,"_",vv,".Rdata",sep=""))

write.csv(z1,paste("mcmc_summary_",uu,"_",id,".csv",sep=""),row.names = F)

sggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdgsggdg



rown <- nrow(data1)
smooth <- 14

para <- c(rep(0,10),rep(1,rown-startpt+1),rep(1,rown-startpt+1))
para[10+210+186-24+1] <- 6

testing <- loglik(data11,data3,para,w_dis,smooth,startpt)
testing[[1]][183:186,]

para[10+210+186-24+1] <- 3

testing <- loglik(data11,data3,para,w_dis,smooth,startpt)
testing[[1]][183:186,]


move <- rep(1,length(para))
move[1:10] <- 0
para[1:10] <- 0
sigma <- (abs(para)+0.1)/5
move[] <- 0
movind <- 370+-10:12
move[movind] <- 1
#move[1:440] <- 0
#move[379] <- 1

data111 <- data11
data111[173:180,4] <- data111[173:180,4]+2
aaaaa1 <- Sys.time()
tt <- mcmc(data111,data3,para,w_dis,smooth,startpt,3000,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)



id <- runif(1,0,1)
inc <- 1000+1:2000
z1 <- para_summary((tt[[1]][inc,movind]),4,3,1)
plot(tt[[2]][inc,1])
print(z1)

370:382-10-210+startpt
#save.image(paste("test_",uu,"_",vv,".Rdata",sep=""))

write.csv(z1,paste("mcmc_summary_",uu,"_",id,".csv",sep=""),row.names = F)

