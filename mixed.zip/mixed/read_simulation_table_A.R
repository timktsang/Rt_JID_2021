
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  y[i,1] <- mean(mcmc[,i])
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


setwd("/Users/timtsang/Dropbox/2019nCoV/rt_method/realdata4/mixed")

rawlist <- list.files(pattern="*.csv")
rawlist1 <- rawlist[grepl("summary_",rawlist)]


#int_para <-  read.csv("/Users/timtsang/Dropbox/2019nCoV/Rt/program_rcpp/sim3/mcmc_summary_89.csv")[,1]
#int_para[11:length(int_para)] <- 1

temp <- read.csv(rawlist1[1])  

int_para <- rep(1,nrow(temp))
nsim <- length(rawlist1)
tt1 <- tt2 <- matrix(NA,nsim,length(int_para))


for (i in 1:nsim){
temp <- read.csv(rawlist1[i])  
tt1[i,] <- temp[,1]
tt2[i,] <- pmax(temp[,1]-temp[,2],temp[,3]-temp[,1])/1.96
}


z1 <- para_summary(tt1,4,3,1)

write.csv(z1,"combined_200.csv",row.names = F)




para_summary2 <- function(mcmc,a,b,print,inputname){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l",axes=T, ann=F, bty="n")
      #  axis(1, at=0:5*200, pos=0, padj=-0.5)
      # axis(2, at=0:ceiling(max(mcmc[,i])), pos=0, padj=-0.5)
      abline(h=y[i,1],col="red")
      mtext(inputname[i],side = 3,cex=0.7)
    }
  }
  return(y)
}

para_summary3 <- function(mcmc,a,b,print,inputname){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(density(mcmc[,i]),type="l",axes=T, ann=F, bty="n")
      #  axis(1, at=0:5*200, pos=0, padj=-0.5)
      # axis(2, at=0:ceiling(max(mcmc[,i])), pos=0, padj=-0.5)
      #  abline(h=y[i,1],col="red")
      mtext(inputname[i],side = 3,cex=0.7)
    }
  }
  return(y)
}

importstart <- 10
localstart <- 10+502/2
## figure
library(chron)
pdf("traceplot_imported.pdf")
z1 <- para_summary2(tt1[,importstart+1:12],4,3,1,paste("Rt for imported cases at ",dates("01/26/2020")+1:94,sep=""))
dev.off()

pdf("traceplot_local.pdf")
z1 <- para_summary2(tt1[,localstart+1:12],4,3,1,paste("Rt for local cases at ",dates("01/26/2020")+1:83,sep=""))
dev.off()

pdf("posterior_imported.pdf")
z1 <- para_summary3(tt1[,importstart+1:12],4,3,1,paste("Rt for imported cases at ",dates("01/26/2020")+1:94,sep=""))
dev.off()

pdf("posterior_local.pdf")
z1 <- para_summary3(tt1[,localstart+1:12],4,3,1,paste("Rt for local cases at ",dates("01/26/2020")+1:83,sep=""))
dev.off()

# number

refdate <- dates("12/31/2019")
###############################################################
## for effectiveness
## here create the covariate
# 1 for imported 14days
data3 <- matrix(0,uu,10)
startd <- dates("2/8/2020")-refdate
data3[startd:nrow(data3),1] <- 1
# 2 work from home
startd <- dates("1/29/2020")-refdate
endd <- dates("3/1/2020")-refdate
data3[startd:endd,2] <- 1
startd <- dates("3/21/2020")-refdate
endd <- dates("5/4/2020")-refdate
data3[startd:min(as.numeric(uu),endd),2] <- 1
startd <- dates("7/20/2020")-refdate
endd <- dates("8/24/2020")-refdate
data3[startd:min(as.numeric(uu),endd),2] <- 1
# high risk place
startd <- dates("3/28/2020")-refdate
endd <- dates("4/23/2020")-refdate
data3[startd:min(as.numeric(uu),endd),3] <- 1
startd <- dates("7/11/2020")-refdate
endd <- dates("9/30/2020")-refdate
data3[startd:min(as.numeric(uu),endd),3] <- 1
startd <- dates("7/18/2020")-refdate
endd <- dates("7/23/2020")-refdate
data3[startd:min(as.numeric(uu),endd),6] <- 1
data3 <- data3[-c(1:23),]


data31 <- matrix(0,nrow(data3),14)
data31[,1] <- 1*(data3[,1]==0)
data31[,2] <- 1*(data3[,1]==1)
tempvec <- c(which(diff(data3[,2])!=0),nrow(data31))
data31[1:tempvec[1],3] <- 1
data31[(tempvec[1]+1):tempvec[2],4] <- 1
data31[(tempvec[2]+1):tempvec[3],5] <- 1
data31[(tempvec[3]+1):tempvec[4],6] <- 1
data31[(tempvec[4]+1):tempvec[5],7] <- 1
data31[(tempvec[5]+1):tempvec[6],8] <- 1
tempvec <- c(which(diff(data3[,3])!=0),nrow(data31))
data31[1:tempvec[1],9] <- 1
data31[(tempvec[1]+1):tempvec[2],10] <- 1
data31[(tempvec[2]+1):tempvec[3],11] <- 1
data31[(tempvec[3]+1):tempvec[4],12] <- 1
data31[,13] <- 1*(data3[,6]==1)
data31[,14] <- 1*(data3[,6]==0)

fit <- tt1

out <- matrix(NA,14,3)
for (i in 1:2){
colllist <- importstart+which(data31[,i]==1)
out[i,1:3] <- quantile(rowMeans(fit[,colllist]),c(0.5,0.025,0.975))
}
for (i in 3:14){
  colllist <- localstart+which(data31[,i]==1)
  out[i,1:3] <- quantile(rowMeans(fit[,colllist]),c(0.5,0.025,0.975))
}
out <- round(out,2)

table1 <- matrix(" ",18,2)
table1[c(1:2,4:9,11:14,17:18),1] <- paste(out[,1]," (",out[,2],", ",out[,3],")",sep="")
table1[grepl("NA",table1)] <- " "

write.csv(table1,"tableA.csv")