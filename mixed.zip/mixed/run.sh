#!/bin/bash
#SBATCH --job-name='zika'
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8gb
#SBATCH --time=10:00:00
#SBATCH --account=epi
#SBATCH --qos=epi
#SBATCH --partition=hpg2-compute

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript rt.r 

date
